﻿class Program
{
    static void Main(string[] args)
    {
        Address address = new Address("07415", "Ukraine", "Zazymia", "Kyivska", "1", "10");
        address.Display();

        Console.ReadLine();
    }
}